#!/system/bin/sh
MODDIR=${0%/*}

function boot_wait() {
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
}

function sf_saturation_boost() {
service call SurfaceFlinger 1023 i32 0
service call SurfaceFlinger 1022 f 1.5
}
boot_wait
sf_saturation_boost

