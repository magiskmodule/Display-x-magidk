#!/bin/sh
MODDIR=${0%/*}
#Blur Remove
resetprop -n ro.surface_flinger.supports_background_blur 0
resetprop -n ro.sf.blurs_are_expensive 0
resetprop -n ro.sf.blurs_are_caro 1
resetprop -n ro.miui.has_real_blur 0
resetprop -n persist.sys.sf.disable_blurs true
resetprop -n disableBlurs true
resetprop -n ro.launcher.blur.appLaunch 0
resetprop -n persist.sys.background_blur_supported false
resetprop -n enable_blurs_on_windows 0

# XtremeSensivity, settings for touch.
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi	
}

# Set Touch Sampling Rate
write /sys/module/msm_ts/parameters/debug_mask 1
write /sys/module/msm_ts/parameters/input_poll_boost 0
write /sys/module/msm_ts/parameters/timer_rate 0
write /sys/module/msm_ts/parameters/delta 5
write /sys/module/msm_ts/parameters/vtg_level 120
write /sys/class/input/event0/sampling_rate 5
write /sys/class/input/event7/sampling_rate 5
