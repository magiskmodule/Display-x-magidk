#!/system/bin/sh
MODDIR=${0%/*}

# Appearance
function boot_wait() {
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
}

function sf_saturation_boost() {
service call SurfaceFlinger 1023 i32 0
service call SurfaceFlinger 1022 f 1.4
}
boot_wait
sf_saturation_boost

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 10
set start vsync

# Set Touch Sampling Rate
echo 1 > /sys/module/msm_ts/parameters/debug_mask
echo 0 > /sys/module/msm_ts/parameters/input_poll_boost
echo 0 > /sys/module/msm_ts/parameters/timer_rate
echo 5 > /sys/module/msm_ts/parameters/delta
echo 120 > /sys/module/msm_ts/parameters/vtg_level
echo 5 > /sys/class/input/event0/sampling_rate
echo 5 > /sys/class/input/event7/sampling_rate

# Exit
exit 0
