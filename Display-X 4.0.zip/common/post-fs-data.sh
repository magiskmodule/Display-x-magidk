#!/bin/sh
MODDIR=${0%/*}

#Blur Remove
resetprop -n ro.surface_flinger.supports_background_blur 0
resetprop -n ro.sf.blurs_are_expensive 0
resetprop -n ro.sf.blurs_are_caro 1
resetprop -n ro.miui.has_real_blur 0
resetprop -n persist.sys.sf.disable_blurs true
resetprop -n disableBlurs true
resetprop -n ro.launcher.blur.appLaunch 0
resetprop -n persist.sys.background_blur_supported false
resetprop -n enable_blurs_on_windows 0
resetprop -n persist.sys.sf.blurs 0
resetprop -n ro.launcher.blur.disabled true
resetprop -n persist.sys.blur.enabled false
resetprop -n persist.sys.background_blur_disabled true
