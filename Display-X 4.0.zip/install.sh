SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

print_modname() {
ui_print "- Tʜᴀɴᴋs Tᴏ                        
 ______                 _                 _         
(_____ \           _   | |               | |        
 _____) )___ ____ | |_ | | _   ___  _ _ _| |        
|  ____/ _  |  _ \|  _)| || \ / _ \| | | | |        
| |   ( ( | | | | | |__| | | | |_| | | | | |_____   
|_|    \_||_|_| |_|\___)_| |_|\___/ \____|_______)  

Display-X                        "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ "
sleep 1
ui_print "📲DEVICE INFORMATION: "
sleep 0.2
ui_print "📲DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "📲BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "📲MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "📲KERNEL : $(uname -r) "
sleep 0.2
ui_print "📲PROCESSOR : $(getprop ro.product.board) "
ui_print "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ "
sleep 1
ui_print ""
ui_print "╔════•ೋೋ•════╗"
ui_print "--- By @PanthowL--- "   
ui_print "╚════•ೋೋ•════╝"
ui_print ""
ui_print "▌Unpacking zip "
ui_print "▌Waiting.... "
sleep 2
ui_print "▌Ready... "
}

on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH/system/bin 0 2000 0755 0755 
  set_perm_recursive $MODPATH/system/app 0 0 0755 0644 
  chmod 0644 $MODPATH/system/etc/be_album
  chmod 0644 $MODPATH/system/etc/be_photo
  chmod 0644 $MODPATH/system/etc/be_movie
  chmod 0644 $MODPATH/system/etc/be_movie_setting
  chmod 0644 $MODPATH/system/etc/be_movie_spc
  chmod 0644 $MODPATH/system/etc/be2_album
  chmod 0644 $MODPATH/system/etc/be2_album01
  chmod 0644 $MODPATH/system/etc/be2_album02
  chmod 0644 $MODPATH/system/etc/be2_album_mapping
  set_perm_recursive $MODPATH/system/framework 0 0 0755 0644
  set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
  }


